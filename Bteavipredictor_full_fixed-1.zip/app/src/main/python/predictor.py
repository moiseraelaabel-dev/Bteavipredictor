def predict(nums):
    """Simple sample prediction function: returns smoothed moving average."""
    if not nums:
        return []
    # simple moving average
    out = []
    window = 3
    for i in range(len(nums)):
        start = max(0, i - window + 1)
        s = sum(nums[start:i+1])
        cnt = i - start + 1
        out.append(s / cnt)
    return out
